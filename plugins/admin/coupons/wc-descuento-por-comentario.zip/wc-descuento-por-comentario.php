<?php
/*
Plugin Name: Descuento por Comentario en WooCommerce
Description: Envía un cupón de descuento a los usuarios que dejen un comentario en un producto de WooCommerce.
Version: 1.0
Author: Bastian
*/

// No permitir el acceso directo al archivo
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Salir si se intenta acceder al archivo directamente
}

function enviar_cupon_descuento_por_comentario( $comment_ID, $comment_approved, $commentdata ) {
    // Verificar si el comentario es de un producto de WooCommerce
    if ( 'product' === get_post_type( $commentdata['comment_post_ID'] ) ) {
        
        // Generar un código único de 8 caracteres
        $codigo_cupon = wp_generate_password( 8, false, false );

        // Crear el cupón en WooCommerce
        $cupon = new WC_Coupon();
        $cupon->set_code( $codigo_cupon );
        $cupon->set_discount_type( 'percent' );
        $cupon->set_amount( '5' );
        $cupon->set_individual_use( true );  // No se puede usar junto con otros cupones
        $cupon->set_usage_limit( 1 );        // Sólo se puede usar una vez
        $cupon->save();

        // Preparar el correo
        $para = $commentdata['comment_author_email'];
        $asunto = '¡Gracias por tu comentario! Aquí tienes un descuento';
        $mensaje = "¡Hola! Gracias por dejar tu comentario en nuestro producto. Aquí tienes un código de descuento del 5% para tu próxima compra: $codigo_cupon. ¡Disfrútalo!";

        // Enviar el correo
        wp_mail( $para, $asunto, $mensaje );
    }
}
add_action( 'comment_post', 'enviar_cupon_descuento_por_comentario', 10, 3 );

